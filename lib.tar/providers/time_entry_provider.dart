import 'package:localstorage/localstorage.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/time_entry.dart';
import '../models/project.dart'

class TimeEntryProvider with ChangeNotifier {
    final 
  List<TimeEntry> _entries = [];

  List<Project> _project = [
    Project('1', 'Project Alpha'),
    Project('2', 'Project Beta'),
    Project('3', 'Project Gamma')
  ];

  List<Task> _task = [
    Tag('1', 'Task 1'),
    Tag('2', 'Task 2'),
    Tag('3', 'Task 3')
  ]

  List<TimeEntry> get entries => _entries;
  void addTimeEntry(TimeEntry entry) {
    _entries.add(entry);
    notifyListeners();
  }
  void deleteTimeEntry(String id) {
    _entries.removeWhere((entry) => entry.id == id);
    notifyListeners();
  }
}
import 'package:flutter/foundation.dart';
import '../models/project.dart';
import '../models/time_entry.dart';
import '../models/task.dart';
import 'package:localstorage/localstorage.dart';
import 'dart:convert';

class TimeEntryProvider with ChangeNotifier {
    final LocalStorage storage;
    // List of Time Entry
    List<TimeEntry> _entries = [];

    // List of project
    List<Project> _projects = [
        Project(id: '1', name: "Project Alpha"),
        Project(id: '2', name: "Project Beta"),
        Project(id: '3', name: "Project Gamma"),
    ];

    List<Task> _task = [
        Task(id: '1', name: "Task A"),
        Task(id: '2', name: "Task B"),
        Task(id: '3', name: "Task C")
    ]

    List<TimeEntry> get entries => _entries;
    List<Project> get project => _projects;
    List<Task> get task => _task;

    TimeEntryProvider(this.storage) {
        _loadTimeEntryProviderFromStorage();
    }

    void _loadTimeEntryProviderFromStorage() async {
        
    }

  void addTimeEntry(TimeEntry entry) {
    _entries.add(entry);
    notifyListeners();
  }

  void deleteTimeEntry(String id) {
    _entries.removeWhere((entry) => entry.id == id);
    notifyListeners();
  }
}
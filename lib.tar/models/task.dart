class Task {
  final String id;
  final String name;
  
  Task({required this.id, required this.name});
}